mytest('oja', 2, 50, ["images/bike.jpg", "images/face.jpg"],'random', [10000, 1000], 'corrupted', [1, 20, 10,10])
mytest('oja', 2, 50, ["images/bike.jpg", "images/face.jpg"],'random', [10000, 1000], 'corrupted', [2, 20, 10,10])

% second rule
mytest('oja', 2, 50, ["images/bike.jpg", "images/face.jpg"],'random', [10000, 1000], 'corrupted', [1, 20, 10,10])
mytest('oja', 2, 50, ["images/bike.jpg", "images/face.jpg"],'random', [10000, 1000], 'corrupted', [2, 20, 10,10])