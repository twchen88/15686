load("data.mat")

learn_hopfield_net(data_10);